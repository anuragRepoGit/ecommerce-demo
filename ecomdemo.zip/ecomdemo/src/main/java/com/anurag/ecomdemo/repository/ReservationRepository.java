@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {}
