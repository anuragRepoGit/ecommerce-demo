public class ReserveRequest {
    private Long itemId;
    private int quantity;
    private String reservedBy;
    // getters and setters
}
