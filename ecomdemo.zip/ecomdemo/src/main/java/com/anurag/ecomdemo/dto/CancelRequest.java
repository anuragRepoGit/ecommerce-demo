public class CancelRequest {
    private Long reservationId;
    // getters and setters
}
