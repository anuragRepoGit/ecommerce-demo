public class SupplyRequest {
    private Long itemId;
    private int quantity;
    // getters and setters
}
