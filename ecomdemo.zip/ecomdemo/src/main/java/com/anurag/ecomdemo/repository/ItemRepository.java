@Repository
public interface ItemRepository extends JpaRepository<Item, Long> {}
