public enum ReservationStatus {
    ACTIVE, CANCELLED
}
